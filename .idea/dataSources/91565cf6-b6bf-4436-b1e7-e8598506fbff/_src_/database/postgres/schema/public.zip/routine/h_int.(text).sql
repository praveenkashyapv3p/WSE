create function h_int(text) returns integer
LANGUAGE SQL
AS $$
select ('x'||substr(md5($1),1,8))::bit(32)::int;
$$;
